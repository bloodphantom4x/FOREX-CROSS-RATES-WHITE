# FOREX CROSS RATES WHITE

A Pen created on CodePen.io. Original URL: [https://codepen.io/Gab-Blood/pen/zxOrQqg](https://codepen.io/Gab-Blood/pen/zxOrQqg).

